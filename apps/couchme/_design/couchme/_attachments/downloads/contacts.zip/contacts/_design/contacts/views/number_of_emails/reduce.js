function(key, values, rereduce) {
    return sum( values );
}
